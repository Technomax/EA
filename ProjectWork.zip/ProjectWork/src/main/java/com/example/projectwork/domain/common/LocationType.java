package com.example.projectwork.domain.common;


public enum LocationType {
    DINNING_HALL, MEDITATION_HALL, FLYING_HALL, CLASSROOM, GYMNASIUM, DORMITORY
}