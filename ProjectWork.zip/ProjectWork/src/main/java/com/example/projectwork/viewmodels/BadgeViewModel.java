package com.example.projectwork.viewmodels;

import com.example.projectwork.domain.Badge;

import java.util.Collection;

public class BadgeViewModel {
    Collection<Badge> badges;
    public BadgeViewModel(Collection<Badge> badges) {
        this.badges = badges;
    }
    public Collection<Badge> getBadges() {
        return this.badges;
    }
}
