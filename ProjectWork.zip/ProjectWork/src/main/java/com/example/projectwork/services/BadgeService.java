package com.example.projectwork.services;

import com.example.projectwork.domain.Badge;
import com.example.projectwork.domain.Member;
import com.example.projectwork.infrastructure.dto.BadgeDto;

import java.util.List;

public interface BadgeService {
    public List<Badge> findAll();
    public BadgeDto findById(long id);
    public BadgeDto findByCode(String code);
    public BadgeDto saveOrUpdate(BadgeDto badge);
    public void remove(long id);
}
