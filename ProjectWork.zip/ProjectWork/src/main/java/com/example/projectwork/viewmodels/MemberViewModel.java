package com.example.projectwork.viewmodels;

import com.example.projectwork.domain.Badge;
import com.example.projectwork.domain.Member;

import java.util.Collection;

public class MemberViewModel {
    Collection<Member> members;
    public MemberViewModel(Collection<Member> members) {
        this.members = members;
    }
    public Collection<Member> getMembers() {
        return this.members;
    }
}
