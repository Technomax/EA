package com.example.projectwork.domain.common;


public enum RecurringType {
    DAILY, WEEKLY, FORTNIGHTLY, MONTHLY
}