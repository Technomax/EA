package com.example.projectwork.controllers;

import com.example.projectwork.CustomErrorType;
import com.example.projectwork.domain.Badge;
import com.example.projectwork.infrastructure.dto.BadgeDto;
import com.example.projectwork.infrastructure.mappers.BadgeMapper;
import com.example.projectwork.services.BadgeService;
import com.example.projectwork.viewmodels.BadgeViewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("badges")
public class BadgeController {
    @Autowired
    private BadgeService badgeService;
    @Autowired
    private BadgeMapper badgeMapper;

    @GetMapping()
    public ResponseEntity<?> getBadges() {
        BadgeViewModel viewModel = new BadgeViewModel(badgeService.findAll());
        return new ResponseEntity<BadgeViewModel>(viewModel, HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<?> getBadge(@PathVariable String id) {
        try {
            BadgeDto model = badgeService.findByCode(id);
            if (model == null)
                return new ResponseEntity<CustomErrorType>(new CustomErrorType("Badge not found."), HttpStatus.NOT_FOUND);
            return new ResponseEntity<BadgeDto>(model, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<CustomErrorType>(new CustomErrorType(ex.getMessage()), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PostMapping()
    public ResponseEntity<?> addBadge(@RequestBody BadgeDto badge) {
        try {
            BadgeDto model = badgeService.saveOrUpdate(badge);
            return new ResponseEntity<BadgeDto>(model, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<CustomErrorType>(new CustomErrorType(ex.getMessage()), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<?> deleteBadge(@PathVariable String id) {
        try {
            BadgeDto model = badgeService.findByCode(id);
            if (model == null)
                return new ResponseEntity<CustomErrorType>(new CustomErrorType("Badge not found for deletion."), HttpStatus.NOT_FOUND);
            badgeService.remove(model.getId());
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception ex) {
            return new ResponseEntity<CustomErrorType>(new CustomErrorType(ex.getMessage()), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping()
    public ResponseEntity<?> updateBadge(@RequestBody BadgeDto badge) {
        try {
            BadgeDto model = badgeService.saveOrUpdate(badge);
            return new ResponseEntity<BadgeDto>(model, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<CustomErrorType>(new CustomErrorType(ex.getMessage()), HttpStatus.EXPECTATION_FAILED);
        }
    }
}
