package com.example.projectwork.infrastructure.dto;

import com.example.projectwork.domain.Membership;
import com.example.projectwork.domain.Role;
import com.example.projectwork.domain.Transaction;
import com.example.projectwork.domain.common.Address;
import com.example.projectwork.domain.common.AuditableWithActive;
import lombok.Data;

import javax.persistence.*;
import java.sql.Blob;
import java.util.HashSet;
import java.util.Set;

@Data
public class MemberDto {
    private long id;
    private String firstName;
    private String lastName;
    @Embedded
    private Address address;
    @Embedded
    private AuditableWithActive auditable;
}
