package com.example.projectwork.domain.common;


public enum PlanType {
   LIMITED, UNLIMITED
}