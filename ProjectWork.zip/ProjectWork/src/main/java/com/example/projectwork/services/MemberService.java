package com.example.projectwork.services;

import com.example.projectwork.domain.Member;
import com.example.projectwork.infrastructure.dto.MemberDto;

import java.util.List;

public interface MemberService {
    public List<Member> findAll();
    public MemberDto findById(long id);
    public MemberDto saveOrUpdate(MemberDto member);
    public void remove(long id);
}
