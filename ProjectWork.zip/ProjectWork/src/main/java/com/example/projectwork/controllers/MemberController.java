package com.example.projectwork.controllers;

import com.example.projectwork.CustomErrorType;
import com.example.projectwork.infrastructure.dto.MemberDto;
import com.example.projectwork.infrastructure.mappers.MemberMapper;
import com.example.projectwork.services.MemberService;
import com.example.projectwork.viewmodels.MemberViewModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("members")
public class MemberController {
    @Autowired
    private MemberService memberService;
    @Autowired
    private MemberMapper memberMapper;

    @GetMapping()
    public ResponseEntity<?> getmembers() {
        MemberViewModel viewModel = new MemberViewModel(memberService.findAll());
        return new ResponseEntity<MemberViewModel>(viewModel, HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<?> getmember(@PathVariable long id) {
        try {
            MemberDto model = memberService.findById(id);
            if (model == null)
                return new ResponseEntity<CustomErrorType>(new CustomErrorType("member not found."), HttpStatus.NOT_FOUND);
            return new ResponseEntity<MemberDto>(model, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<CustomErrorType>(new CustomErrorType(ex.getMessage()), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PostMapping()
    public ResponseEntity<?> addmember(@RequestBody MemberDto member) {
        try {
            MemberDto model = memberService.saveOrUpdate(member);
            return new ResponseEntity<MemberDto>(model, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<CustomErrorType>(new CustomErrorType(ex.getMessage()), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @DeleteMapping("{id}")
    public ResponseEntity<?> deletemember(@PathVariable Long id) {
        try {
            MemberDto model = memberService.findById(id);
            if (model == null)
                return new ResponseEntity<CustomErrorType>(new CustomErrorType("member not found for deletion."), HttpStatus.NOT_FOUND);
            memberService.remove(model.getId());
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception ex) {
            return new ResponseEntity<CustomErrorType>(new CustomErrorType(ex.getMessage()), HttpStatus.EXPECTATION_FAILED);
        }
    }

    @PutMapping()
    public ResponseEntity<?> updatemember(@RequestBody MemberDto member) {
        try {
            MemberDto model = memberService.saveOrUpdate(member);
            return new ResponseEntity<MemberDto>(model, HttpStatus.OK);
        } catch (Exception ex) {
            return new ResponseEntity<CustomErrorType>(new CustomErrorType(ex.getMessage()), HttpStatus.EXPECTATION_FAILED);
        }
    }
}
