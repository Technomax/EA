package com.example.projectwork.domain;

import com.example.projectwork.domain.common.AuditableWithActive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="memberships")
public class Membership {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    @Column(name="startDate", nullable = false)
    private LocalDate startDate;
    @Column(name="endDate", nullable = true)
    private LocalDate endDate;
    @Embedded
    private AuditableWithActive auditable;
}
