package com.example.projectwork.infrastructure.mappers;

import com.example.projectwork.domain.Member;
import com.example.projectwork.infrastructure.dto.MemberDto;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface MemberMapper {
    MemberDto domainToDto(Member domain);

    Member dtoToDomain(MemberDto dto);
}
